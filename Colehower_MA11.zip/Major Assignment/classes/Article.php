<?php

class Article{

    public $id;
    public $title;
    public $content;
    public $published_at; 
    
   public static function getAll($conn){

        $sql = " SELECT *
        From article 
        ORDER BY published_at;"; 

    $result = $conn->query($sql); 

     return $result->fetchAll(PDO::FETCH_ASSOC); 


   }

   /**
    * Get the article record based on the ID
    * 
    * @param object $conn Connection to the database 
    * @param integer $id the article ID
    * @param string $columns Optional list of columns for the select, default is * 
    * @return mixed An assocaiative array containing the article with that ID, or nut if not
     */
   
   
   public static function getByID($conn, $id, $columns = '*')
   {
       $sql = " SELECT $columns
           From article 
           WHERE id = :id"; 
   
       $stmt = $conn->prepare($sql); 
   
      
           
           $stmt->bindValue(':id', $id, PDO::PARAM_INT); 

           $stmt->setFetchMode(PDO::FETCH_CLASS, 'Article'); 
   
           if($stmt->execute()){
               
               return $stmt->fetch(); 
           }
   }

}