<?php

$db_host = "elvisdb.rowan.edu";
$db_name = "coleho43";
$db_user = "coleho43"; 
$db_pass = "17FuzzyBrownCat!!"; 

$conn = mysqli_connect ($db_host,  $db_user, $db_pass, $db_name);

if(mysqli_connect_error()){
    echo mysqli_connect_error();
    exit;
}



$sql = " SELECT *
        From article 
        ORDER BY published_at"; 
$result = mysqli_query($conn, $sql); 

if ($result === FALSE){
    echo mysqli_error($conn);
}else {
    $articles = mysqli_fetch_all($result, MYSQLI_ASSOC);

}

?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset ="UTS-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title> 
</head>
<body>

    <header>
        <h1> My Blog </h1>
    </header>
    <main> 
        <?php if (empty($articles)): ?>
            <p>NO ARTICLES FOUND. </p>
        <?php else: ?>
        <ul>
            <?php foreach($articles as $article): ?>
            <li>
                <article>
                    <h2><?= $article['title']; ?> </h2>
                    <p><?= $article['content']; ?></p>
                </article>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?> 
    </main>
</body>
</html>
