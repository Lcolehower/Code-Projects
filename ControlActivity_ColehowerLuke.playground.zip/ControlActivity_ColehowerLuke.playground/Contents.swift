import UIKit
/* Control Activity: Switching Challenge
 Luke Colehower 20240923 Section 1
 */

var str = "Hello, playground"

/**** Swift Switching Challenges *****/

/* Problem 1:

Write a switch statement for Characters that determines whether a given
character is a vowel (for the purposes of this assignment "y" is considered a
vowel), consonant, or number. Write the switch in the most efficient way you
can, using Swifty mechanisms like compound cases or ranges, if appropriate.
Note that the character MAY not be a letter or Number, so if it is neither,
print "Unrecognized Character".
*/

let someCharacter: Character = "o"

switch someCharacter {
case "a", "e", "i", "o", "u", "y":
   print("\(someCharacter) is a vowel")
case "b"..."z":
   print("\(someCharacter) is a consonant")
case "0"..."9":
   print("\(someCharacter) is a number")
default:
   print("\(someCharacter) is an Unrecognized Character")
}

/* Problem 2:

Write a switch statement for Integers that determines whether a given
number is positive, negative, or 0. Write the switch in the most efficient way
you can, using Swifty mechanisms like compound cases or ranges, if appropriate.
*/

let someNumber: Int = -11

switch someNumber {
case let x where x > 0:
   print("\(someNumber) is Positive")
case let x where x < 0:
   print("\(someNumber) is Negative")
default:
   print("\(someNumber) is Zero")
}

/* Problem 3:

Write a switch statement for (String, Int) Tuples that represent a person's
name and age. The switch will bind to the name, and have cases for ages under
18 (juvenile), 18-55 (adult), and over 55 (senior). Each case should print the
person's name & a message that identifies which group they're in.
*/

let person: (name: String, age: Int) = ("Luke", 24)

switch person {
case (let name, let age) where age < 18:
   print("\(name) is a juvenile")
case (let name, let age) where age <= 55:
   print("\(name) is an adult")
case (let name, _):
   print("\(name) is a senior")
}

/* Problem 4:

Write a switch statement for (String, Double) Tuples that represent a person's
name and bank account $ value. Each case should print a message, using the name
that describes their account. If the account == 0, print a message telling them
to make a deposit. If the account is < 0, print the same message AND a message
telling them that the account is overdrawn. If it is > 0, then print a nice greeting
and the balance.
*/

let account: (name: String, balance: Double) = ("Luke", 20.45)

switch account {
case (let name, let balance) where balance > 0:
   print("Hello \(name), your balance is $\(balance)")
case (let name, let balance) where balance == 0:
   print("Hello \(name), please make a deposit")
case (let name, let balance) where balance < 0:
   print("Hello \(name), your account is overdrawn. Balance: $\(balance)")
default:
   print("Unrecognized case for \(account.name)'s account.")
}

/* Problem 5:

Write a switch statement for (Int, Int) tuples that will determine and print
their Quadrant on a Coordinate Plane (numbered starting in the upper right,
and going counter clockwise):

       y
     2 | 1
   x -----
     3 | 4

Tuples may have coordinates like (0, 0) or (105, 0), which indicate
a point on the origin or one of the axes. In this scenario, bind to the values,
print them, and a message explaining which axis or origin they are on.
*/

let coordinate: (Int, Int) = (105, 105)

switch coordinate {
case (0, 0):
   print("Point (0, 0) is at the origin")
case (0, let y):
   print("Point (0, \(y)) is on the Y-axis")
case (let x, 0):
   print("Point (\(x), 0) is on the X-axis")
case (let x, let y) where x > 0 && y > 0:
   print("Point (\(x), \(y)) is in Quadrant 1")
case (let x, let y) where x < 0 && y > 0:
   print("Point (\(x), \(y)) is in Quadrant 2")
case (let x, let y) where x < 0 && y < 0:
   print("Point (\(x), \(y)) is in Quadrant 3")
case (let x, let y) where x > 0 && y < 0:
   print("Point (\(x), \(y)) is in Quadrant 4")
default:
   print("Point (\(coordinate.0), \(coordinate.1)) is out of bounds")
}
