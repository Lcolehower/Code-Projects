<?php

class User
{
    public $id; 
    public $username;
    public $password; 

    public static function authenticate($conn, $username,  $password ) 
    {
        $sql = "SELECT *
                FROM user
                WHERE username = :username"; 
        
        $stmt = $conn->prepare($sql); 
        $stmt->bindValue(':username', $username, PDO::PARAM_STR); 

        $stmt->setFetchMode(PDO::FETCH_CLASS, 'User'); 

        $stmt->execute(); 

        if($user = $stmt->fetch()){
            return password_verify($password, $user->password); 
              
        }
    }
    public static function addUser($conn, $username, $password)
    {
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO users (username, password_hash)
                VALUES (:username, :password_hash)";

        $stmt = $conn->prepare($sql);
        $stmt->bindValue(':username', $username, PDO::PARAM_STR);
        $stmt->bindValue(':password_hash', $password_hash, PDO::PARAM_STR);

        if ($stmt->execute()) {
            // Return the ID of the last inserted row
            return $conn->lastInsertId();
        } else {
            return false;
        }
    }

}
    
