<?php

require '../includes/init.php'; 

Auth::requireLogin(); 

$conn = require '../includes/db.php'; 

$articles = Article::getAll($conn); 


?> 
<?php require '../includes/header.php'; ?>



<h2>Administration Page</h2>
    
    <P><a href="new-article.php">Add New Article</a></P>

        <?php if (empty($articles)): ?>
            <p>NO ARTICLES FOUND. </p>
        <?php else: ?>

        <table>
            <thead>
                <th>Title</th>
            </thead>
            <tbody> 
                    <?php foreach($articles as $article): ?>
                    <tr>
                        <td>
                            <a href="article.php?id=<?= $article['id']; ?>" ><?= 
                            htmlspecialchars($article['title']); ?></a>
    
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody> 
        </table>

        <?php endif; ?> 
        <?php require '../includes/footer.php'; ?>