<?php
require 'includes/init.php';

// Initialize variables for form data and errors
$username = '';
$password = '';
$errors = [];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and validate input data
    $username = trim($_POST['username']);
    $password = $_POST['password']; // Don't trim passwords

    if (empty($username)) {
        $errors[] = 'Username is required';
    }

    if (empty($password)) {
        $errors[] = 'Password is required';
    }

    // Check if the username already exists
    if (empty($errors)) {
        $conn = require 'includes/db.php';
        $sql = 'SELECT * FROM users WHERE username = :username';
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(':username', $username, PDO::PARAM_STR);
        $stmt->execute();

        if ($stmt->fetch()) {
            $errors[] = 'Username is already taken';
        }
    }


    // If there are no errors, insert the new user into the database
    if (empty($errors)) {
        // Use password_hash() to securely hash the password
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        $conn = require 'includes/db.php';
        $sql = 'INSERT INTO users (username, password_hash) VALUES (:username, :password_hash)';
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(':username', $username, PDO::PARAM_STR);
        $stmt->bindValue(':password_hash', $password_hash, PDO::PARAM_STR);

        if ($stmt->execute()) {
            // Include the Auth class
            require 'classes/Auth.php';
            // Login the user
            Auth::login();
            // Redirect to the admin page after successful registration
            header('Location: /~coleho43/admin/');
            
        } else {
            $errors[] = 'Failed to create user account. Please try again.';
        }
    }
}

?>
<?php require 'includes/header.php'; ?>

<div class="container mt-5">
    <h2>Register</h2>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?php echo $error; ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" class="form-horizontal">
        <div class="form-group">
            <label for="username" class="col-sm-2 control-label">Username</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="username" name="username"
                       value="<?php echo htmlspecialchars($username); ?>" placeholder="Enter username">
            </div>
        </div>
        <div class="form-group">
            <label for="password" class="col-sm-2 control-label">Password</label>
            <div class="col-sm-10">
                <input type="password" class="form-control" id="password" name="password"
                       placeholder="Enter password">
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-default">Register</button>
            </div>
        </div>
        <div class="col-sm-offset-2 col-sm-10">
            <p>Already have an account? <a href="login.php">Login</a></p>
        </div>
    </form>
</div>

<?php require 'includes/footer.php'; ?>