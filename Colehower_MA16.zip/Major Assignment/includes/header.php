<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset ="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Intro Web Developement</title> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    

</head>
<body>

    <header>
        <h1> Luke's Web Page </h1>
    
    </header>
    <nav>
        <ul>
        
        <li><a  href="/~coleho43/">Home</a></li>

        <?php if (Auth::isLoggedIn()): ?> 
    
             <li><a  href="/~coleho43/admin/">Admin </a></li>
             <li><a  href="/~coleho43/logout.php">Log Out </a></li>

        <?php else: ?>

            <li><a href="/~coleho43/login.php">Log In </a> </li>
            <li><a href="/~coleho43/register.php">Register </a> </li>

        <?php endif; ?>


        </ul>
    </nav>
    <main> 