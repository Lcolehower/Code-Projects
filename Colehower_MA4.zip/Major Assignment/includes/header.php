<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset ="UTS-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title> 
</head>
<body>

    <header>
        <h1> My Blog </h1>
    </header>
    <main> 