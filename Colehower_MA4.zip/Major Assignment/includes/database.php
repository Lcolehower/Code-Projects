<?php

$db_host = "elvisdb.rowan.edu";
$db_name = "coleho43";
$db_user = "coleho43"; 
$db_pass = "17FuzzyBrownCat!!"; 

$conn = mysqli_connect ($db_host,  $db_user, $db_pass, $db_name);

if(mysqli_connect_error()){
    echo mysqli_connect_error();
    exit;
}