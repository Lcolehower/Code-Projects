// Weekday.swift
// protocolsChallenge
// Partner: Imohimi Unuigbe
// Created by Luke Colehower on 11/26/24.
//  Copyright © 2021 Jacob Levy. All rights reserved.

import Foundation

enum Weekday: Int {
    case Sunday
    case Monday
    case Tuesday
    case Wednesday
    case Thursday
    case Friday
    case Saturday
}
