// main.swift
// protocolsChallenge
// Partner: Imohimi Unuigbe
// Created by Luke Colehower on 11/26/24.
//  Copyright © 2021 Jacob Levy. All rights reserved.

import Foundation

// Example CalendarView for January 2024 (Leap Year) starting on Monday
let january2024 = CalendarView(currentMonth: .January, leap: true, startingDay: .Monday)
print(january2024)

// Example CalendarView for February 2024 (Leap Year) starting on Thursday
let february2024 = CalendarView(currentMonth: .February, leap: true, startingDay: .Thursday)
print(february2024)

// Example CalendarView for March 2024 (Non-Leap Year) starting on Wednesday
let march2024 = CalendarView(currentMonth: .March, leap: false, startingDay: .Wednesday)
print(march2024)
