// CalendarView.swift
// protocolsChallenge
// Partner: Imohimi Unuigbe
// Created by Luke Colehower on 11/26/24.
//  Copyright © 2021 Jacob Levy. All rights reserved.

import Foundation

struct CalendarView: tableDataSource, CustomStringConvertible {

   var currentMonth: Month
   var leap: Bool
   var startingDay: Weekday

   // tableDataSource conformance
   var numberOfColumns: Int {
       return 7
   }

   var numberOfRows: Int {
       return 6
   }

   func label(forColumn column: Int) -> String {
       switch column {
       case 0: return "Sun"
       case 1: return "Mon"
       case 2: return "Tue"
       case 3: return "Wed"
       case 4: return "Thu"
       case 5: return "Fri"
       case 6: return "Sat"
       default: return ""
       }
   }

   func itemFor(row: Int, column: Int) -> String {
       let daysInMonth = currentMonth.numDays(leap)
       let startDayOffset = startingDay.rawValue
       let totalDays = row * 7 + column - startDayOffset
      
       if totalDays >= 0 && totalDays < daysInMonth {
           return String(totalDays + 1)
       } else {
           return "XX"
       }
   }

   // CustomStringConvertible conformance
   var description: String {
       var calendarString = ""

       // Header row with day labels
       for column in 0..<numberOfColumns {
           calendarString += label(forColumn: column) + "  "
       }
       calendarString += "\n"

       // Loop through each row and column to add the days
       for row in 0..<numberOfRows {
           for column in 0..<numberOfColumns {
               let day = itemFor(row: row, column: column)
              
               // Use padding to ensure all days are of equal width
               calendarString += day.padding(toLength: 5, withPad: " ", startingAt: 0)
           }
           calendarString += "\n"
       }

       return calendarString
   }
}
