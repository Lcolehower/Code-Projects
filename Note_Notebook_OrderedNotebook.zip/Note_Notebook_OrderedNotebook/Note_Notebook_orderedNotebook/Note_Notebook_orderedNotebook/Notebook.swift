//
//  Notebook.swift
//  Note_Notebook_orderedNotebook
//Partner Imohimi Unuigbe
//  Created by Colehower, Luke Talbot on 11/18/24.
//

import Foundation

class Notebook {
    var notes: [String: Note] = [:]
   
    var count: Int {
        return notes.count
    }
   
    init(firstNote: Note? = nil) {
        if let note = firstNote {
            notes[note.id] = note
        }
    }
   
    func insert(note: Note) {
        notes[note.id] = note
    }
   
    func remove(note: Note) -> Note? {
        return notes.removeValue(forKey: note.id)
    }
   
    func copy(note: Note) -> String {
        var newNote = note
        newNote.title = "\(newNote.title)-\(self.count + 1)"
        notes[newNote.id] = newNote
        return newNote.id
    }
   
    func retrieve(noteWith name: String) -> Note? {
        return notes.values.first { $0.title == name }
    }
   
    func printNotes() {
        print("\n=== Notes ===")
        if notes.isEmpty {
            print("No notes available.")
        } else {
            for note in notes.values {
                print("Title: \(note.title)\nBody: \(note.body)\nPriority: \(note.priority)\n")
            }
        }
    }
}
