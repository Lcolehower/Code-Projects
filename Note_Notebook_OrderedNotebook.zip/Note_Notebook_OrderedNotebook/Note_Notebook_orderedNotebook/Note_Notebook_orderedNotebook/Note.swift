//
//  main.swift
//  Note_Notebook_orderedNotebook
//Partner Imohimi Unuigbe
//  Created by Colehower, Luke Talbot on 11/18/24.
// Note.swift
import Foundation

struct Note {
    enum PriorityLvl: Int {
        case low = 0, med = 1, high = 2

        mutating func incrementLvl() {
            if self.rawValue < 2 {
                self = PriorityLvl(rawValue: self.rawValue + 1)!
            }
        }

        mutating func decrementLvl() {
            if self.rawValue > 0 {
                self = PriorityLvl(rawValue: self.rawValue - 1)!
            }
        }
    }

    // Static calendar instance to format dates
    static var calendar: Calendar = Calendar(identifier: .gregorian)

    // Properties
    static var idGen = 0

    var title: String
    var body: String
    var id: String
    var priority: PriorityLvl
    var creationDate: Date

    // Lazy event date, default is 24 hours after creationDate
    lazy var eventDate: Date = {
        return creationDate.addingTimeInterval(24 * 60 * 60) // 24 hours later
    }()

    // Initializer
    init(title: String, body: String) {
        self.title = title
        self.body = body
        self.id = "\(title)\(Note.idGen)"
        self.priority = .low
        self.creationDate = Date()  // Default to current date/time
        Note.idGen += 1
    }

    // Function to update the note title
    mutating func updateName(with name: String) -> String {
        let oldTitle = title
        title = name
        return oldTitle
    }

    // Function to update the note body
    mutating func updateBody(with text: String) -> String {
        let oldBody = body
        body = text
        return oldBody
    }

    // Function to append text to the note body
    mutating func appendBody(with text: String) {
        body.append(text)
    }

    // Function to set a custom event date
    mutating func setEventDate(event: Date?) {
        if let event = event {
            eventDate = event
        } else {
            eventDate = creationDate.addingTimeInterval(24 * 60 * 60) // Reset to default
        }

        // Print the formatted event date using the Gregorian calendar
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        let formattedDate = formatter.string(from: eventDate)
        print("Event Date set to: \(formattedDate)")
    }
}
