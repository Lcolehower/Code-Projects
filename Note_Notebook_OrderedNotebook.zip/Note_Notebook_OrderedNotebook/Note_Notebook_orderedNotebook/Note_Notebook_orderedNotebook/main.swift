//
//  main.swift
//  Note_Notebook_orderedNotebook
// Partner Imohimi Unuigbe
//  Created by Colehower, Luke Talbot on 11/18/24.
//
import Foundation

// Test Part 1: Create some Notes
var note1 = Note(title: "Shopping List", body: "Buy eggs, milk, and bread.")
note1.priority.incrementLvl()

var note2 = Note(title: "Work", body: "Complete Swift project.")

var note3 = Note(title: "Exercise", body: "Run 5 miles.")

// Test Part 2: Create a Notebook and add Notes
let notebook = Notebook()
notebook.insert(note: note1)
notebook.insert(note: note2)
notebook.insert(note: note3)

print("\n=== Testing Notebook ===")
notebook.printNotes()

// Test copy
let copiedNoteId = notebook.copy(note: note1)
print("Copied Note ID: \(copiedNoteId)\n")

// Test Part 3: Create an OrderedNotebook and add Notes
let orderedNotebook = OrderedNotebook(firstNote: note1)
orderedNotebook.append(note: note2)
orderedNotebook.insert(note: note3, at: 1)

print("\n=== Testing Ordered Notebook ===")
orderedNotebook.printNotes()

// Test sorting
orderedNotebook.sort(using: { $0.value.priority.rawValue > $1.value.priority.rawValue })
print("\n=== Sorted Ordered Notebook ===")
orderedNotebook.printNotes()

// Test setting event date
note1.setEventDate(event: Date().addingTimeInterval(48 * 60 * 60)) // Set to 2 days from now
