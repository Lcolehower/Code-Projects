//
//  OrderedNotebook.swift
//  Note_Notebook_orderedNotebook
//Partner Imohimi Unuigbe
//  Created by Colehower, Luke Talbot on 11/18/24.
//
import Foundation

class OrderedNotebook: Notebook {
    var ordered: [String] = []
   
    override init(firstNote: Note? = nil) {
        super.init(firstNote: firstNote)
        if let note = firstNote {
            ordered.append(note.id)
        }
    }
   
    override func copy(note: Note) -> String {
        let copiedNoteId = super.copy(note: note)
        ordered.append(copiedNoteId)
        return copiedNoteId
    }
   
    override func remove(note: Note) -> Note? {
        ordered.removeAll { $0 == note.id }
        return super.remove(note: note)
    }
   
    override func printNotes() {
        print("\n=== Ordered Notebook ===")
        if ordered.isEmpty {
            print("No notes available.")
        } else {
            for id in ordered {
                if let note = notes[id] {
                    print("Title: \(note.title)\nBody: \(note.body)\nPriority: \(note.priority)\n")


                }
            }
        }
    }
   
    func append(note: Note) {
        ordered.append(note.id)
        insert(note: note)
    }
   
    func insert(note: Note, at position: Int) {
        if position < 0 || position >= ordered.count {
            append(note: note)
        } else {
            ordered.insert(note.id, at: position)
            insert(note: note)
        }
    }
   
    func move(note from: Int, to position: Int) -> (moved: Bool, position: Int?) {
        if from < 0 || from >= ordered.count || position < 0 {
            return (false, nil)
        }
       
        let noteId = ordered[from]
        ordered.remove(at: from)
       
        if position >= ordered.count {
            ordered.append(noteId)
        } else {
            ordered.insert(noteId, at: position)
        }
       
        return (true, position)
    }
   
    func move(note: Note, to position: Int) -> (moved: Bool, position: Int?) {
        guard let fromIndex = ordered.firstIndex(of: note.id) else {
            return (false, nil)
        }
        return move(note: fromIndex, to: position)
    }
   
    func sort(using closure: ((key: String, value: Note), (key: String, value: Note)) -> Bool) {
        let sortedKeys = notes.sorted(by: closure).map { $0.key }
        ordered = sortedKeys
    }
}
