<?php

require 'includes/database.php';

$conn = getDB(); 

if(  isset($_GET['id']) && is_numeric($_GET['id'])) {

$sql = " SELECT *
        From article 
        WHERE id = " . $_GET['id']; 


$result = mysqli_query($conn, $sql); 

if ($result === FALSE){
    echo mysqli_error($conn);
}else {
    $article = mysqli_fetch_assoc($result);

}

}else{
    $article = null;
}

?> 

<?php require 'includes/header.php'; ?>

        <?php if ($article === null): ?>
            <p>Article Not Found. </p>
        <?php else: ?>
        
                <article>
                    <h2><?= htmlspecialchars($article['title']); ?> </h2>
                    <p><?= htmlspecialchars($article['content']) ; ?></p>
                </article>
            
           
        <?php endif; ?> 
        <?php require 'includes/footer.php'; ?>
    