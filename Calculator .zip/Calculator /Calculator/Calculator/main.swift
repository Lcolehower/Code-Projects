//
//  main.swift
//  Calculator
// Partner Imohimi Unuigbe 
//  Created by Colehower, Luke Talbot on 10/9/24.
//

import Foundation
func printMenu() {
    print("""
    Please select an operation:
    a for Addition
    s for Subtraction
    m for Multiplication
    d for Division
    % for Modulus
    """)
}

func add(a: Double, b: Double) -> Double? {
    return a + b
}

func subtract(a: Double, b: Double) -> Double? {
    return a - b
}

func multiply(a: Double, b: Double) -> Double? {
    return a * b
}

func divide(num: Double, denom: Double) -> Double? {
    guard denom != 0 else { return nil } // Prevent division by zero
    return num / denom
}

func modulus(a: Double, b: Double) -> Double? {
    guard a.truncatingRemainder(dividingBy: 1) == 0,
          b.truncatingRemainder(dividingBy: 1) == 0 else { return nil }
   
    let intA = Int(a)
    let intB = Int(b)
   
    return Double(intA % intB)
}

var calculate: (Double, Double) -> Double?

while true {
    printMenu()
   
    guard let choice = readLine()?.lowercased() else { continue }
   
    switch choice {
    case "a":
        calculate = add
    case "s":
        calculate = subtract
    case "m":
        calculate = multiply
    case "d":
        calculate = divide
    case "%":
        calculate = modulus
    default:
        print("Unrecognized choice, please try again.")
        continue
    }
   
    print("Enter the first number:")
    guard let input1 = readLine(), let number1 = Double(input1) else {
        print("Invalid input, please enter a number.")
        continue
    }
   
    print("Enter the second number:")
    guard let input2 = readLine(), let number2 = Double(input2) else {
        print("Invalid input, please enter a number.")
        continue
    }
   
    let result = calculate(number1, number2)
    print("Result: \(result != nil ? String(result!) : "Invalid Operation")")
    

}
