<?php


class Database
{
    public function getConn()
    {
        $db_host = "elvisdb.rowan.edu";
        $db_name = "coleho43";
        $db_user = "coleho43"; 
        $db_pass = "17FuzzyBrownCat!!"; 

        $dsn = 'mysql:host=' . $db_host . ';dbname=' . $db_name . ';charset=utf8'; 

        try
        {
            $db = new PDO($dsn, $db_user, $db_pass);
            
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            return $db; 
        
        }catch (PDOException $e){
            echo $e->getMessage();
            exit; 

        }
    }
}