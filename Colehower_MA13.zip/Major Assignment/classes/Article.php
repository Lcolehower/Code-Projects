<?php

class Article{

    public $id;
    public $title;
    public $content;
    public $published_at; 

    public $errors = []; 
    
   public static function getAll($conn){

        $sql = " SELECT *
        From article 
        ORDER BY published_at;"; 

    $result = $conn->query($sql); 

     return $result->fetchAll(PDO::FETCH_ASSOC); 


   }

   /**
    * Get the article record based on the ID
    * 
    * @param object $conn Connection to the database 
    * @param integer $id the article ID
    * @param string $columns Optional list of columns for the select, default is * 
    * @return mixed An assocaiative array containing the article with that ID, or nut if not
     */
   
   
   public static function getByID($conn, $id, $columns = '*')
   {
       $sql = " SELECT $columns
           From article 
           WHERE id = :id"; 
   
       $stmt = $conn->prepare($sql); 
   
      
           
           $stmt->bindValue(':id', $id, PDO::PARAM_INT); 

           $stmt->setFetchMode(PDO::FETCH_CLASS, 'Article'); 
   
           if($stmt->execute()){
               
               return $stmt->fetch(); 
           }
   }
 public function update($conn)
 {
    if($this->validate())
    {

        $sql = "UPDATE article
                 SET title = :title,
                 content = :content,
                published_at = :published_at
                WHERE id = :id"; 
    
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(':id', $this->id, PDO::PARAM_INT); 
        $stmt->bindValue(':title', $this->title, PDO::PARAM_STR);
        $stmt->bindValue(':content', $this->content, PDO::PARAM_STR);
        if($this->published_at == '')
        {
        $stmt->bindValue(':published_at', $this->published_at, null, PDO::PARAM_NULL); 
        }else{
        $stmt->bindValue(':published_at', $this->published_at, PDO::PARAM_STR); 
        }
        return $stmt->execute(); 
    }else{
      return false; 
    }
} 
protected function validate()
 {
     
     if($this->title == ''){
         $this->errors[] = 'Title is Required'; 
     }
     if($this->content == ''){
         $this->errors[] = 'Content is Required'; 
     }
     if($this->published_at != ''){
        $date_time = date_create_from_format('Y-m-d\TH:i', $this->published_at); 
     
        if($date_time === false){
         $this->errors[] = 'Invalid date and time.'; 
        }else{
         
         $date_errors = date_get_last_errors(); 
        
         if($date_errors['warning_count'] > 0){
             $this->errors[] = 'Invalid date and time.'; 
         }
        }
     }
     return empty($this->errors); 
  }  
  
  public function delete($conn)
  {
    $sql = "DELETE FROM article
                WHERE id = :id"; 
    
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(':id', $this->id, PDO::PARAM_INT); 

        return $stmt->execute(); 
  }

  public function create($conn)
  {
     if($this->validate())
     {
 
         $sql = "INSERT INTO article (title, content, published_at)
                VALUE (:title, :content, :published_at)"; 
     
         $stmt = $conn->prepare($sql);
        
         $stmt->bindValue(':title', $this->title, PDO::PARAM_STR);
         $stmt->bindValue(':content', $this->content, PDO::PARAM_STR);
         if($this->published_at == '')
         {
         $stmt->bindValue(':published_at', $this->published_at, null, PDO::PARAM_NULL); 
         }else{
         $stmt->bindValue(':published_at', $this->published_at, PDO::PARAM_STR); 
         }
         if($stmt->execute()){
            $this->id = $conn->lastInsertID(); 
            return true; 
         } 
     }else{
       return false; 
    }
    }
} 
