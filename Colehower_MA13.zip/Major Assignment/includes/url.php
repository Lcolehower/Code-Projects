<?php

/**
 * Redirect to Another URl on the same site
 * @param string $path the path to redirect to
 * @return void 
 */

function redirect($path){
    if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off'){
        $protocol = 'https';
     }else{
        $protocol = 'http';
     }
//File are in the ~coleho43 directly

     header("Location: $protocol://" . $_SERVER['HTTP_HOST'] . "/~coleho43" . $path);
     exit; 

}