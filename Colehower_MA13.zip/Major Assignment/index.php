<?php

require 'classes/Database.php';
require 'classes/Article.php';
require 'includes/auth.php';

session_start(); 

$db = new Database(); 

$conn = $db->getConn(); 

$articles = Article::getAll($conn); 


?> 
<?php require 'includes/header.php'; ?>


<?php if (isLoggedIn()): ?> 
    
    <p> You are succesffuly logged in <a  href="logout.php">Log Out </a> </p>
    <p> <a href="new-article.php">Add New Article</a> </p>

<?php else: ?>

        <p>You are not logged in <a href="login.php">Log In </a> </p>

<?php endif; ?>



        <?php if (empty($articles)): ?>
            <p>NO ARTICLES FOUND. </p>
        <?php else: ?>
        <ul>
            <?php foreach($articles as $article): ?>
            <li>
                <article>
                    <h2><a href="article.php?id=<?= $article['id']; ?>" ><?= htmlspecialchars($article['title']); ?></a></h2>
                    <p><?= htmlspecialchars($article['content']); ?></p>
                </article>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?> 
        <?php require 'includes/footer.php'; ?>