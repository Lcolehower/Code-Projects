<?php

/**
 * Get the article record based on the ID
 * 
 * @param object $conn Connection to the database 
 * @param integer $id the article ID
 * @param string $columns Optional list of columns for the select, default is * 
 * @return mixed An assocaiative array containing the article with that ID, or nut if not
  */


function getArticle($conn, $id, $columns = '*')
{
    $sql = " SELECT $columns
        From article 
        WHERE id = ?"; 

    $stmt = mysqli_prepare($conn, $sql);

    if($stmt === false){
        echo mysqli_error($conn); 
    }else{
        
        mysqli_stmt_bind_param($stmt, "i", $id); 

        if(mysqli_stmt_execute($stmt)){
            
            $result = mysqli_stmt_get_result($stmt);
            return mysqli_fetch_array($result, MYSQLI_ASSOC);
        }
    }
}


/**
 * Validate the article properties 
 *  @param string $title Title , required
 * @param string $content Content, required
 * @param string $published_at date and time, yyyy-mm-dd hh:mm:ss if not blank
 * 
 * @return array An array of validation error messages 
 */ 
function validateArticle($title, $content, $published_at)
{
    
    $errors = []; 

    if($title == ''){
        $errors[] = 'Title is Required'; 
    }
    if($content == ''){
        $errors[] = 'Content is Required'; 
    }
    if($published_at != ''){
       $date_time = date_create_from_format('Y-m-d\TH:i', $published_at); 
    
       if($date_time === false){
        $errors[] = 'Invalid date and time.'; 
       }else{
        
        $date_errors = date_get_last_errors(); 
       
        if($date_errors['warning_count'] > 0){
            $errors[] = 'Invalid date and time.'; 
        }
       }
    }
    return $errors; 
}
