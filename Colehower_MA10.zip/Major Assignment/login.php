<?php
require 'includes/url.php'; 

session_start(); 

if ($_SERVER["REQUEST_METHOD"] == "POST"){
    
    if($_POST['username'] == 'Luke' && $_POST['password'] == 'R3D'){

        session_regenerate_id(true); 
       
        $_SESSION['is_logged_in'] = true; 
        Redirect('/');

    }else{
        $error = "login incorrect";
    }
}
?>

<?php require 'includes/header.php'; ?>

<h2>Login</h2>
<?php if (! empty($error)): ?> 
    
    <P><?= $error ?></P>

<?php endif; ?> 

<form method="post">
    <div>
        <label for="username">Username</label>
        <input name="username" id="username">
    </div>
    <div>
        <label for="password">Password</label>
        <input type="password" name="password" id="username">
    </div>
    
    <button>Log In</button>
</form>


<?php require 'includes/footer.php'; ?>
