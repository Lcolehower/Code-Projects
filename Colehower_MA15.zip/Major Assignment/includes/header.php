<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset ="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Intro Web Developement</title> 
</head>
<body>

    <header>
        <h1> My Blog </h1>
    </header>
    <nav>
        <ul>
        
        <li><a  href="/~coleho43/">Home</a></li>

        <?php if (Auth::isLoggedIn()): ?> 
    
             <li><a  href="/~coleho43/admin/">Admin </a></li>
             <li><a  href="/~coleho43/logout.php">Log Out </a></li>

        <?php else: ?>

            <li><a href="/~coleho43/login.php">Log In </a> </li>

        <?php endif; ?>


        </ul>
    </nav>
    <main> 